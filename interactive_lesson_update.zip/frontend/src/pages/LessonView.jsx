// (Shortened due to length; use full version from previous step with injected buttons + progress)
